exports.helloGET = (req, res) => {
    res.send("Hello World!\n");
};
